package com.example.engine;

public interface IImage {
    public int getWidth();
    public int getHeight();
}
