package com.example.engine;

public interface IFont {
    public int getSize();
    public boolean isBold();
}
