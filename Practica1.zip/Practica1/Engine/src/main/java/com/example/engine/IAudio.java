package com.example.engine;

public interface IAudio {
    public class ISound
    {

    };
public ISound newSound();
}
