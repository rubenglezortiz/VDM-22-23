package com.example.engine;

public interface IState {
    public void update();
    public void render();
}
