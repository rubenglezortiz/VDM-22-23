package com.example.engine;
import com.example.engine.IColor;

public interface IColor{

}
