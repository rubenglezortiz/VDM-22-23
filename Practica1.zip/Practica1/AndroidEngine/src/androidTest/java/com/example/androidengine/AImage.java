package com.example.androidengine;

import android.graphics.Bitmap;

import com.example.engine.IImage;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class AImage implements IImage {

    private InputStream is;
    Bitmap bitmap;

    int width, height;

    public AImage(String name, int width_, int height_){

        width = width_;
        height = height_;
    }

    @Override
    public int getWidth() {
        return 0;
    }

    @Override
    public int getHeight() {
        return 0;
    }
}
