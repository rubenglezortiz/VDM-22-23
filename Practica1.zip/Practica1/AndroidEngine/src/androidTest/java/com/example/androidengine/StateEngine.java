package com.example.androidengine;

import com.example.engine.IState;

public class StateEngine implements IState {

    public void update(){

    }

    public void render(){

    }
}
